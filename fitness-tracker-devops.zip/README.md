# Fitness Tracker DevOps Project
This project uses Kubernetes to deploy and manage microservices for a fitness tracker app.
